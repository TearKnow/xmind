<?php

if(!function_exists("dd")){
    function dd(...$args){
        http_response_code(500);
        echo "<pre>";
        foreach($args as $x){
            var_dump($x);
        }
        exit;
    }
}