<?php


namespace models;


class User extends BaseDao
{

}