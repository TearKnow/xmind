<?php
namespace models;

use Medoo\Medoo;
class BaseDao extends Medoo
{
    public function __construct()
    {
        $options = [
            'database_type' => 'mysql',
            'database_name' => 'goodcomposer',
            'server' => 'localhost',
            'username' => 'root',
            'password' => '',
            'prefix' => 'jack_',
        ];
        parent::__construct($options);
    }
}