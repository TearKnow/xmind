<?php

namespace controllers;

error_reporting(E_ALL);
ini_set('display_errors', true);

use models\BaseDao;
use models\User;
use Slince\Upload\UploadHandlerBuilder;
use Intervention\Image\ImageManager as Image;
use JasonGrimes\Paginator;

class Test extends BaseControllers {
    function index(){
        //1. 测试加载单个文件
//        dd('this is index', 'bb', array(11, 22));

        //2. 使用twig & 使用model
        $user = new User;
        $data = $user->select('user', "*");
        $this->assign('userlist', $data);

        $this->display('index');
    }

    function guanli(){
        $this->display('list');
    }

    function catelist(){
//        $this->display('cate');
        $this->success('/list', '成功了，其实这里是一些crud，这里不做了，要返回到列表了');
    }

    function booklist($num = 1){
        $user = new BaseDao();
        $totalItems = $user->count('user');
        $itemsPerPage = 10;
        $currentPage = $num;
        $urlPattern = '/booklist/(:num)';

        $paginator = new Paginator($totalItems, $itemsPerPage, $currentPage, $urlPattern);

        $start = ($currentPage - 1) * $itemsPerPage;
        $data = $user->select('user', "*", ['LIMIT' => [$start, $itemsPerPage]]);
        $this->assign('fpage', $paginator);
        $this->assign('books', $data);
        $this->display('book');
    }

    function add(){

        //使用上传的包
        $path = dirname(dirname(__DIR__)) . "/uploads";

        $builder = new UploadHandlerBuilder(); //create a builder.
        $handler = $builder
            ->allowExtensions(['png', 'jpg'])
            ->allowMimeTypes(['image/*'])
            ->saveTo($path)
            ->getHandler();
        $files = $handler->handle();
        $filename = $files['filename']->getUploadedFile()->getClientOriginalName(); // original name

        echo 'upload ' . $filename;
//        foreach ($files as $file) {
//            $uploadedFile = $file->getUploadedFile();
//            if ($file->isUploaded()) {
//                echo $uploadedFile->getClientOriginalName() . ' upload ok, path:' . $file->getDetails()->getPathname();
//            } else {
//                echo $uploadedFile->getClientOriginalName() . ' upload error: ' . $file->getException()->getMessage();
//            }
//            echo PHP_EOL;
//        }

        //打水印略，因为要安装GD库
//        $obj = new Image();
//        $img = $obj->make($path . '/' . $filename);
//        $img->resize(150, 240);
//        $img->insert($path . '/watermark.png');
//        $img->save($path . '/' . 'pre_' . $filename);


    }
}