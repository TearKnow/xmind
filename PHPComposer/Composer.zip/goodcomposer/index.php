<?php
    require('vendor/autoload.php');
    use NoahBuscher\Macaw\Macaw;

    /*
     * 入口链接是 /list
     *
     * 用到的一些包
     * 1. 路由: noahbuscher/macaw
     * 2. 视图: twig/twig
     * 3. 模型: catfan/medoo
     * 4. 图片上传：slince/upload
     * 5. 图片处理包： intervention/image
     * 6. 分页类：jasongrimes/paginator
     * */
    ini_set('display_errors', true);

    //1. 使用回调
    Macaw::get('/', function(){
        echo 'this is /';
    });

    //2. 使用controller
    Macaw::get('/index', 'controllers\Test@index');

    //3. 有些地方加载单个文件, helpers.php这个文件，也在composer.json里加载了

    //4. 图书管理
    Macaw::get('/list', 'controllers\Test@guanli');
    Macaw::get('/catelist', 'controllers\Test@catelist');
    Macaw::get('/booklist', 'controllers\Test@booklist');
    Macaw::get('/booklist/(:num)', 'controllers\Test@booklist');

    //5. 图片上传的包
    Macaw::post('/add', 'controllers\Test@add');

    Macaw::dispatch();