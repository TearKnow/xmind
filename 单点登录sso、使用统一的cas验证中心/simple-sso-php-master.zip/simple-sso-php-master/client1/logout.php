<?php
session_start();
session_destroy();
?>

<script type="text/javascript">
	alert("Logout Sukses!");
	document.location.href="home.php";
</script>