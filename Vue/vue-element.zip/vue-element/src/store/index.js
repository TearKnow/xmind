// import Vue from 'vue'
// import Vuex from 'vuex';
//
// Vue.use(Vuex);
//
// //保持所有组件的公共数据
// const state = sessionStorage.getItem('state') ? JSON.parse(sessionStorage.getItem('state')) :{
//   user:{
//     name:''
//   }
// };
//
// //监听state对象值的最新状态（计算属性，缓存）
// const getters={
//   getUser(state){
//     return state.user;
//   }
// };
//
// //唯一一个可以修改state的方法(同步执行，阻塞)
// const mutations={
//   updateUser(state, user){
//     state.user = user;
//   }
// };
//
// //异步执行mutations
// const actions = {
//   asyncUpdateUser(context, user){
//     context.commit('updateUser', user);
//   }
// }
//
//
// export default new Vuex.Store({
//   state,
//   mutations,
//   getters,
//   actions
// })

//上面的写法不是模块化的，下面的是模块化的，推荐使用

import Vue from 'vue'
import Vuex from 'vuex';
import user from './modules/user';

Vue.use(Vuex);

export default new Vuex.Store({
  modules:{
    user
  }
})
