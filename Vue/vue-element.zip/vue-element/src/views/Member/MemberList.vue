<template>
  <div>
    会员列表
  </div>
</template>

<script>
    export default {
        name: "MemberList"
    }
</script>

<style scoped>

</style>
